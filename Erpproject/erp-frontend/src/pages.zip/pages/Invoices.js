import React, { useEffect, useState } from "react";
import api from "../api/axios";

export default function Invoices() {
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const res = await api.get("/invoices");
        setInvoices(res.data);
      } catch (err) {
        console.error("Failed to fetch invoices:", err);
      }
    };
    fetchInvoices();
  }, []);

  const download = (id) => {
    // Open PDF in new tab
    window.open(`http://localhost:8080/api/invoices/${id}/pdf`);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Invoices</h2>
      {invoices.length === 0 ? (
        <p>No invoices available.</p>
      ) : (
        <table border={1} cellPadding={10}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Customer</th>
              <th>Total</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv) => (
              <tr key={inv.id}>
                <td>{inv.id}</td>
                <td>{inv.salesOrder?.customer?.name || "N/A"}</td>
                <td>{inv.totalPayable}</td>
                <td>{inv.status}</td>
                <td>
                  <button onClick={() => download(inv.id)}>Download PDF</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
