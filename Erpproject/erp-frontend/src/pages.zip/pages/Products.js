import api from "../api/axios";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";

export default function Products() {

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);

  // ========================
  // Load Products
  // ========================
  const loadProducts = async () => {
    try {
      setLoading(true);

      const res = await api.get("/products");

      // Spring pagination compatibility
      const data = res.data.content || res.data;

      setProducts(data);

    } catch (err) {
      toast.error("Failed to load products");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  // ========================
  // UI
  // ========================
  if (loading) {
    return <p>Loading products...</p>;
  }

  return (
    <div>

      <h2>Products</h2>

      {products.length === 0 ? (
        <p>No products found</p>
      ) : (

        <table border="1" cellPadding="8">

          <thead>
            <tr>
              <th>Name</th>
              <th>Stock</th>
              <th>Price</th>
            </tr>
          </thead>

          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td>{p.currentStock}</td>
                <td>{p.unitPrice}</td>
              </tr>
            ))}
          </tbody>

        </table>

      )}

    </div>
  );
}
