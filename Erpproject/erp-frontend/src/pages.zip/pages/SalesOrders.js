import api from "../api/axios";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";

export default function SalesOrders() {

  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);

  const [customerId, setCustomerId] = useState("");
  const [productId, setProductId] = useState("");
  const [quantity, setQuantity] = useState(1);

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);

  // ======================
  // Load dropdown data
  // ======================
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const c = await api.get("/customers");
      const p = await api.get("/products");

      setCustomers(c.data.content || c.data);
      setProducts(p.data.content || p.data);

    } catch {
      toast.error("Failed to load customers/products");
    }
  };

  // ======================
  // Add Item
  // ======================
  const addItem = () => {

    if (!productId || quantity <= 0) {
      toast.error("Invalid product or quantity");
      return;
    }

    const product = products.find(p => p.id === Number(productId));

    if (!product) {
      toast.error("Product not found");
      return;
    }

    // Prevent duplicate product
    const exists = items.find(i => i.productId === product.id);

    if (exists) {
      toast.error("Product already added");
      return;
    }

    const item = {
      productId: product.id,
      productName: product.name,
      quantity: Number(quantity),
      unitPrice: product.unitPrice
    };

    setItems([...items, item]);

    // Reset input
    setProductId("");
    setQuantity(1);
  };

  // ======================
  // Create Order
  // ======================
  const createOrder = async () => {

    if (!customerId || items.length === 0) {
      toast.error("Customer and items required");
      return;
    }

    try {
      setLoading(true);

      await api.post("/sales-orders", {

        customer: {
          id: Number(customerId)
        },

        items: items.map(i => ({
          product: {
            id: i.productId
          },
          quantity: i.quantity
        }))
      });

      toast.success("Sales Order Created Successfully");

      // Reset form
      setItems([]);
      setCustomerId("");

    } catch (err) {

      console.error(err);

      toast.error(
        err.response?.data?.message || "Sales Order creation failed"
      );

    } finally {
      setLoading(false);
    }
  };

  // ======================
  // UI
  // ======================
  return (
    <div style={{ padding: "20px" }}>

      <h2>Create Sales Order</h2>

      {/* CUSTOMER */}
      <select
        value={customerId}
        onChange={e => setCustomerId(e.target.value)}
      >
        <option value="">Select Customer</option>

        {customers.map(c => (
          <option key={c.id} value={c.id}>
            {c.name}
          </option>
        ))}
      </select>

      <hr />

      {/* PRODUCT */}
      <select
        value={productId}
        onChange={e => setProductId(e.target.value)}
      >
        <option value="">Select Product</option>

        {products.map(p => (
          <option key={p.id} value={p.id}>
            {p.name} (Stock: {p.currentStock})
          </option>
        ))}
      </select>

      <input
        type="number"
        min="1"
        value={quantity}
        onChange={e => setQuantity(e.target.value)}
      />

      <button onClick={addItem}>
        Add Item
      </button>

      <hr />

      {/* ITEMS */}
      {items.length === 0 && <p>No items added</p>}

      {items.map((i, index) => (
        <div key={index}>
          {i.productName}
          {" — Qty: "}
          {i.quantity}
        </div>
      ))}

      <hr />

      <button onClick={createOrder} disabled={loading}>
        {loading ? "Saving..." : "Submit Order"}
      </button>

    </div>
  );
}
